param([string]$GameDirectory,[string]$UserDataDirectory)
$ErrorActionPreference='Stop'
$packageRoot=Split-Path -Parent $MyInvocation.MyCommand.Path
$utf8=New-Object System.Text.UTF8Encoding($false)
function Get-PackageHash([string]$Path){
    $inputStream=[IO.File]::OpenRead($Path);$hash=[Security.Cryptography.SHA256]::Create()
    try{return ([BitConverter]::ToString($hash.ComputeHash($inputStream))).Replace('-','')}finally{$inputStream.Dispose();$hash.Dispose()}
}
function Save-Json($path,$value) {[IO.File]::WriteAllText($path,($value|ConvertTo-Json -Depth 12),$utf8)}
function Safe-Child([string]$root,[string]$relative) {
    if([string]::IsNullOrWhiteSpace($relative) -or [IO.Path]::IsPathRooted($relative) -or $relative.Contains(':') -or ($relative -split '[/\\]') -contains '..'){throw 'Unsafe package path'}
    $prefix=[IO.Path]::GetFullPath($root).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
    $result=[IO.Path]::GetFullPath((Join-Path $prefix $relative))
    if(-not $result.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){throw 'Path outside intended directory'}
    return $result
}
function Check-GameClosed {
    foreach($process in @(Get-Process -Name 'Operator 112' -ErrorAction SilentlyContinue)) {
        try {$image=$process.Path} catch {$image=$null}
        if(-not $image -or [IO.Path]::GetFullPath($image) -eq (Join-Path $GameDirectory 'Operator 112.exe')){throw 'Close 112 Operator before installing.'}
    }
}
if(-not $GameDirectory){$GameDirectory=Read-Host 'Paste the game directory containing Operator 112.exe'}
$GameDirectory=[IO.Path]::GetFullPath($GameDirectory.Trim().Trim('"'))
if(-not (Test-Path -LiteralPath (Join-Path $GameDirectory 'Operator 112.exe') -PathType Leaf)){throw 'Operator 112.exe was not found. Use Steam > Manage > Browse local files.'}
if(-not $UserDataDirectory){$UserDataDirectory=Join-Path $env:USERPROFILE 'AppData\LocalLow\JutsuGames\112 Operator'}
$UserDataDirectory=[IO.Path]::GetFullPath($UserDataDirectory)
Check-GameClosed
$manifest=Get-Content -LiteralPath (Join-Path $packageRoot 'prerequisite_manifest.json') -Raw -Encoding UTF8|ConvertFrom-Json
foreach($file in $manifest.files){
    $source=Safe-Child $packageRoot $file.path
    if(-not (Test-Path -LiteralPath $source -PathType Leaf) -or (Get-PackageHash $source) -ne $file.sha256){throw ('Prerequisite package is incomplete or changed: '+$file.path)}
}
$main=Join-Path $GameDirectory 'Operator 112_Data\Managed\Main.dll'
if(-not (Test-Path -LiteralPath $main -PathType Leaf) -or (Get-PackageHash $main) -ne $manifest.game_main_sha256){throw 'This game build is not verified for this release. Send the author your game version; no game files were changed.'}
$core=Join-Path $GameDirectory 'BepInEx\core\BepInEx.dll'
$installLoader=-not (Test-Path -LiteralPath $core -PathType Leaf)
if(-not $installLoader){
    if((Get-Item -LiteralPath $core).VersionInfo.FileVersion -ne '5.4.23.5'){throw 'Existing BepInEx version differs from 5.4.23.5. Preserve it and contact the author.'}
} else {
    foreach($name in @('winhttp.dll','doorstop_config.ini')){if(Test-Path -LiteralPath (Join-Path $GameDirectory $name)){throw ('Another loader already owns '+$name+'. Contact the author before integrating it.')}}
}
$plugins=Join-Path $GameDirectory 'BepInEx\plugins'
$moves=New-Object System.Collections.ArrayList
$moveSources=New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
if(Test-Path -LiteralPath $plugins){
    foreach($name in @('MerantiCoreCallsRuntime','MerantiC09LocationRuntime')){
        $path=Safe-Child $plugins $name
        if(Test-Path -LiteralPath $path){[void]$moveSources.Add($path)}
    }
    $legacy=@('MerantiCoreCallsRuntime','MerantiC09LocationRuntime','MerantiTwoDutyRuntime')
    foreach($dll in Get-ChildItem -LiteralPath $plugins -Recurse -File -Filter '*.dll'){
        try{$assemblyName=[Reflection.AssemblyName]::GetAssemblyName($dll.FullName).Name}catch{continue}
        if($legacy -contains $assemblyName){
            $insideKnown=$false
            foreach($parent in $moveSources){if($dll.FullName.StartsWith($parent.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){$insideKnown=$true;break}}
            if(-not $insideKnown){[void]$moveSources.Add($dll.FullName)}
        }
    }
}
$myMods=Join-Path $UserDataDirectory 'MyMods'
$oldMods=@()
if(Test-Path -LiteralPath $myMods){
    foreach($dir in Get-ChildItem -LiteralPath $myMods -Directory){
        $definition=Join-Path $dir.FullName 'Scenarios\sc_moranti_xiamen\sc_moranti_xiamen.json'
        if((Test-Path -LiteralPath $definition) -and -not (Test-Path -LiteralPath (Join-Path $dir.FullName 'MerantiRelease.json'))){$oldMods+=$dir.FullName}
    }
}
$stamp=Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$backup=Join-Path $GameDirectory ('MerantiWorkshop_Backups\'+$stamp)
$userBackup=Join-Path $UserDataDirectory ('MerantiWorkshop_Backups\'+$stamp)
$stateTarget=Join-Path $UserDataDirectory 'MerantiWorkshop\sc_moranti_xiamen\CityDynamic\state'
$stateSources=@()
foreach($path in $moveSources){if((Get-Item -LiteralPath $path).PSIsContainer){
    foreach($relative in @('CityDynamicCandidate\state','CityPrepCandidate\state')){
        $state=Join-Path $path $relative
        if(Test-Path -LiteralPath $state -PathType Container){$stateSources+=$state}
    }
}}
$receipt=@{schema=1;bootstrap_version='1.0.0';game_directory=$GameDirectory;user_data_directory=$UserDataDirectory;backup=$backup;user_backup=$userBackup;status='STARTED';moved=@();installed=@();state_copied=@();state_conflicts_preserved=@()}
New-Item -ItemType Directory -Path $backup,$userBackup -Force|Out-Null
$receiptPath=Join-Path $backup 'installation.json'
Save-Json $receiptPath $receipt
try {
    # Copy-once state migration: conflicting current state is retained, old state remains in the backup.
    foreach($source in $stateSources){
        foreach($file in Get-ChildItem -LiteralPath $source -Recurse -File){
            $relative=$file.FullName.Substring($source.TrimEnd('\').Length+1)
            $dest=Safe-Child $stateTarget $relative
            if(Test-Path -LiteralPath $dest){
                if((Get-PackageHash $dest) -ne (Get-PackageHash $file.FullName)){$receipt.state_conflicts_preserved+=@{existing=$dest;old_source=$file.FullName}}
                continue
            }
            New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
            Copy-Item -LiteralPath $file.FullName -Destination $dest
            if((Get-PackageHash $dest) -ne (Get-PackageHash $file.FullName)){throw 'State migration hash mismatch'}
            $receipt.state_copied+=$dest
        }
    }
    Check-GameClosed
    foreach($source in $moveSources){
        $relative=$source.Substring($plugins.TrimEnd('\').Length+1)
        $checked=Safe-Child $plugins $relative
        $dest=Safe-Child (Join-Path $backup 'old_plugins') $relative
        if($checked -ne $source){throw 'Legacy plugin path verification failed'}
        New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
        Move-Item -LiteralPath $source -Destination $dest
        $receipt.moved+=@{source=$source;backup=$dest}; Save-Json $receiptPath $receipt
    }
    foreach($source in $oldMods){
        $relative=$source.Substring($myMods.TrimEnd('\').Length+1)
        $checked=Safe-Child $myMods $relative
        if($checked -ne $source){throw 'Legacy scenario path verification failed'}
        $dest=Safe-Child $userBackup $relative
        Move-Item -LiteralPath $source -Destination $dest
        $receipt.moved+=@{source=$source;backup=$dest}; Save-Json $receiptPath $receipt
    }
    if($installLoader){
        $staging=Join-Path $backup 'loader_source'
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        [IO.Compression.ZipFile]::ExtractToDirectory((Join-Path $packageRoot 'BepInEx_win_x64_5.4.23.5.zip'),$staging)
        foreach($file in Get-ChildItem -LiteralPath $staging -File -Recurse){
            $relative=$file.FullName.Substring($staging.TrimEnd('\').Length+1)
            $dest=Safe-Child $GameDirectory $relative
            if(Test-Path -LiteralPath $dest){
                if($relative -eq 'changelog.txt'){continue}
                throw ('Loader target already exists: '+$relative)
            }
            New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
            Copy-Item -LiteralPath $file.FullName -Destination $dest
            $receipt.installed+=@{path=$dest;sha256=(Get-PackageHash $dest)};Save-Json $receiptPath $receipt
        }
    }
    $bootstrap=Safe-Child $plugins 'MerantiWorkshopBootstrap\MerantiWorkshopBootstrap.dll'
    if(Test-Path -LiteralPath $bootstrap){
        $dest=Join-Path $backup 'previous_bootstrap.dll'
        Move-Item -LiteralPath $bootstrap -Destination $dest
        $receipt.moved+=@{source=$bootstrap;backup=$dest};Save-Json $receiptPath $receipt
    }
    New-Item -ItemType Directory -Path (Split-Path -Parent $bootstrap) -Force|Out-Null
    Copy-Item -LiteralPath (Join-Path $packageRoot 'MerantiWorkshopBootstrap.dll') -Destination $bootstrap
    $expected=($manifest.files|Where-Object {$_.path -eq 'MerantiWorkshopBootstrap.dll'}).sha256
    if((Get-PackageHash $bootstrap) -ne $expected){throw 'Installed bootstrap hash mismatch'}
    $receipt.installed+=@{path=$bootstrap;sha256=$expected};$receipt.status='SUCCESS';Save-Json $receiptPath $receipt
    Write-Host 'Meranti prerequisite installed. Subscribe to the matching Workshop item, wait for download, then restart the game and start a new scenario.'
    Write-Host ('Receipt and rollback source: '+$receiptPath)
    if($receipt.state_conflicts_preserved.Count){Write-Warning 'Existing state differs from old state. Both copies were preserved; no state was overwritten.'}
} catch {
    $receipt.status='FAILED';$receipt.error=$_.Exception.Message;Save-Json $receiptPath $receipt
    Write-Warning ('Installation stopped. All backups and the receipt were kept at '+$backup)
    throw
}
