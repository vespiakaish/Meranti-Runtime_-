param([Parameter(Mandatory=$true)][string]$Receipt)
$ErrorActionPreference='Stop'
function Get-PackageHash([string]$Path){
    $inputStream=[IO.File]::OpenRead($Path);$hash=[Security.Cryptography.SHA256]::Create()
    try{return ([BitConverter]::ToString($hash.ComputeHash($inputStream))).Replace('-','')}finally{$inputStream.Dispose();$hash.Dispose()}
}
$r=Get-Content -LiteralPath $Receipt -Raw -Encoding UTF8|ConvertFrom-Json
$game=[IO.Path]::GetFullPath($r.game_directory).TrimEnd('\')+'\'
$user=[IO.Path]::GetFullPath($r.user_data_directory).TrimEnd('\')+'\'
foreach($process in @(Get-Process -Name 'Operator 112' -ErrorAction SilentlyContinue)){
    try{$image=$process.Path}catch{$image=$null}
    if(-not $image -or $image -eq (Join-Path $r.game_directory 'Operator 112.exe')){throw 'Close the game before rollback.'}
}
foreach($item in $r.installed){
    $path=[IO.Path]::GetFullPath($item.path)
    if(-not $path.StartsWith($game,[StringComparison]::OrdinalIgnoreCase)){throw 'Receipt path outside game directory'}
    if((Test-Path -LiteralPath $path) -and (Get-PackageHash $path) -ne $item.sha256){throw ('Installed file changed; rollback stopped: '+$path)}
}
foreach($item in $r.moved){
    $path=[IO.Path]::GetFullPath($item.source)
    $backup=[IO.Path]::GetFullPath($item.backup)
    if(-not ($path.StartsWith($game,[StringComparison]::OrdinalIgnoreCase) -or $path.StartsWith($user,[StringComparison]::OrdinalIgnoreCase))){throw 'Receipt restore target outside intended directories'}
    if(-not ($backup.StartsWith(([IO.Path]::GetFullPath($r.backup).TrimEnd('\')+'\'),[StringComparison]::OrdinalIgnoreCase) -or $backup.StartsWith(([IO.Path]::GetFullPath($r.user_backup).TrimEnd('\')+'\'),[StringComparison]::OrdinalIgnoreCase))){throw 'Receipt backup outside intended directories'}
    if(Test-Path -LiteralPath $path){if(-not (@($r.installed.path) -contains $path)){throw ('Restore target is occupied; preserve the new files first: '+$path)}}
    if(-not (Test-Path -LiteralPath $backup)){throw ('Backup is missing: '+$backup)}
}
$archive=Join-Path $r.backup ('rollback_preserved_'+(Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
New-Item -ItemType Directory -Path $archive -Force|Out-Null
foreach($item in $r.installed){
    if(Test-Path -LiteralPath $item.path){
        $relative=([IO.Path]::GetFullPath($item.path)).Substring($game.Length)
        $dest=Join-Path $archive $relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
        Move-Item -LiteralPath $item.path -Destination $dest
    }
}
foreach($item in @($r.moved)[($r.moved.Count-1)..0]){
    if($null -eq $item){continue}
    New-Item -ItemType Directory -Path (Split-Path -Parent $item.source) -Force|Out-Null
    Move-Item -LiteralPath $item.backup -Destination $item.source
}
Write-Host 'Rollback complete. Migrated state and all replaced files were preserved.'
