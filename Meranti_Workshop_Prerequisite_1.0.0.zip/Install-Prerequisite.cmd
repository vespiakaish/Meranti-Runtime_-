@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-MerantiPrerequisite.ps1"
set result=%errorlevel%
pause
exit /b %result%
